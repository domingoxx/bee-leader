function OnSignerStartup() {
    return "Approve"
}
function OnApprovedTx() {
    return "Approve"
}
function ApproveListing() {
    return "Approve"
}
function ApproveTx() {
    return "Approve"
}
function ApproveSignData() {
    return "Approve"
}